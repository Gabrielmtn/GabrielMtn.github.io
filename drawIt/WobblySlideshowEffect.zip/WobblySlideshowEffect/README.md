Wobbly Slideshow Effect
=========

The slides in this slideshow wobble as they move. The effect is based on Sergey Valiukh's Dribbble shot and was made using Snap.svg and morphing SVG paths.

[Article on Codrops](http://tympanus.net/codrops/?p=20714)

[Demo](http://tympanus.net/Development/WobblySlideshowEffect/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

Icons by [Pixel Buddha](http://pixelbuddha.net/)

[© Codrops 2014](http://www.codrops.com)